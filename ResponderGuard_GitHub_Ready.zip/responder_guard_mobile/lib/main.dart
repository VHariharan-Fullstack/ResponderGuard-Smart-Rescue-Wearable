import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const ResponderGuardApp());

class ResponderGuardApp extends StatelessWidget {
  const ResponderGuardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ResponderGuard',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const Dashboard(),
    );
  }
}

class Reading {
  final String name;
  final String value;
  final String unit;
  final bool danger;
  const Reading(this.name, this.value, this.unit, this.danger);
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final _random = Random();
  Timer? _timer;

  int hr = 82, spo2 = 98, rr = 17, sys = 120, dia = 78;
  int co = 8, co2 = 520, o2 = 20, battery = 91;
  bool bluetooth = true;
  bool cloud = true;
  bool emergency = false;
  final List<String> incidents = [];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => simulate());
  }

  void simulate() {
    if (!mounted) return;
    setState(() {
      hr = (hr + _random.nextInt(7) - 3).clamp(55, 190);
      spo2 = (spo2 + _random.nextInt(3) - 1).clamp(82, 100);
      rr = (rr + _random.nextInt(3) - 1).clamp(10, 35);
      co = (co + _random.nextInt(9) - 4).clamp(0, 120);
      co2 = (co2 + _random.nextInt(41) - 20).clamp(350, 3000);
      battery = max(1, battery - (_random.nextInt(20) == 0 ? 1 : 0));
      emergency = hr > 150 || spo2 < 90 || co > 50 || o2 < 18;
    });
  }

  void triggerDemoEmergency() {
    setState(() {
      co = 75;
      spo2 = 87;
      hr = 158;
      emergency = true;
      incidents.insert(0, 'Critical alert: toxic exposure / cardiac risk');
    });
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Emergency Detected'),
        content: const Text(
          'Prototype workflow activated.\n\n'
          '• Mobile/control center alerted\n'
          '• GPS location prepared\n'
          '• Nearest-hospital alert simulated\n'
          '• Personal-contact alert simulated\n'
          '• Incident saved offline/cloud queue',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Acknowledge'),
          )
        ],
      ),
    );
  }

  void reset() {
    setState(() {
      hr = 82; spo2 = 98; rr = 17; sys = 120; dia = 78;
      co = 8; co2 = 520; o2 = 20; emergency = false;
    });
  }

  List<Reading> get readings => [
    Reading('Heart Rate', '$hr', 'bpm', hr > 150 || hr < 50),
    Reading('Blood Pressure', '$sys/$dia', 'mmHg', sys > 180 || sys < 85),
    Reading('SpO₂', '$spo2', '%', spo2 < 90),
    Reading('Respiratory Rate', '$rr', 'breaths/min', rr > 30 || rr < 10),
    Reading('CO', '$co', 'ppm', co > 50),
    Reading('O₂', '$o2', '%', o2 < 18),
    Reading('CO₂', '$co2', 'ppm', co2 > 2000),
  ];

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ResponderGuard'),
        actions: [
          Icon(bluetooth ? Icons.bluetooth_connected : Icons.bluetooth_disabled),
          const SizedBox(width: 12),
          Icon(cloud ? Icons.cloud_done : Icons.cloud_off),
          const SizedBox(width: 16),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: emergency
                ? Theme.of(context).colorScheme.errorContainer
                : Theme.of(context).colorScheme.primaryContainer,
            child: ListTile(
              leading: Icon(emergency ? Icons.warning_amber : Icons.health_and_safety),
              title: Text(emergency ? 'CRITICAL CONDITION' : 'Responder Stable'),
              subtitle: Text(
                emergency
                    ? 'Abnormal health/environmental reading detected'
                    : 'Continuous monitoring active',
              ),
              trailing: Text('$battery% 🔋'),
            ),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: readings.length,
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 230,
              childAspectRatio: 1.45,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemBuilder: (_, i) {
              final r = readings[i];
              return Card(
                color: r.danger
                    ? Theme.of(context).colorScheme.errorContainer
                    : null,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(r.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 7),
                      Text(r.value, style: Theme.of(context).textTheme.headlineSmall),
                      Text(r.unit),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 18),
          const Text('Emergency & Connectivity',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SwitchListTile(
            value: bluetooth,
            onChanged: (v) => setState(() => bluetooth = v),
            title: const Text('Bluetooth Low Energy'),
            subtitle: const Text('Wearable connection simulation'),
          ),
          SwitchListTile(
            value: cloud,
            onChanged: (v) => setState(() => cloud = v),
            title: const Text('Cloud Sync'),
            subtitle: Text(cloud ? 'Cloud + offline logging' : 'Offline logging active'),
          ),
          ListTile(
            leading: const Icon(Icons.location_on),
            title: const Text('Emergency Location'),
            subtitle: const Text('GPS: simulated • Share with hospital & contacts'),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: triggerDemoEmergency,
            icon: const Icon(Icons.emergency),
            label: const Text('Simulate Emergency'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: reset,
            icon: const Icon(Icons.restart_alt),
            label: const Text('Reset Readings'),
          ),
          const SizedBox(height: 20),
          const Text('Team Monitoring',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const Card(
            child: Column(children: [
              ListTile(
                leading: CircleAvatar(child: Text('R1')),
                title: Text('Responder 01'),
                subtitle: Text('Connected • Stable'),
                trailing: Icon(Icons.check_circle),
              ),
              Divider(height: 1),
              ListTile(
                leading: CircleAvatar(child: Text('R2')),
                title: Text('Responder 02'),
                subtitle: Text('Connected • Monitoring'),
                trailing: Icon(Icons.sensors),
              ),
            ]),
          ),
          if (incidents.isNotEmpty) ...[
            const SizedBox(height: 18),
            const Text('Incident History',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...incidents.map((e) => ListTile(
              leading: const Icon(Icons.history),
              title: Text(e),
              subtitle: const Text('Stored in local incident log'),
            )),
          ],
          const SizedBox(height: 20),
          const Text(
            'Educational prototype only — simulated readings are not for medical diagnosis or real emergency dispatch.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
