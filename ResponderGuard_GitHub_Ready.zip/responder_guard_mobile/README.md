# ResponderGuard – Smart Responder Safety Mobile Prototype

ResponderGuard is a Flutter software prototype for monitoring rescue personnel working in hazardous environments.

## Features
- Real-time heart rate, BP, SpO2 and respiratory-rate monitoring
- CO, O2 and CO2 environmental monitoring
- Automatic abnormal-condition detection
- Emergency alert simulation for gas poisoning / cardiac risk
- GPS-style location sharing workflow
- Hospital and personal-contact alert simulation
- Bluetooth connection status simulation
- Cloud/offline storage status
- Battery monitoring
- Incident history
- Multi-responder monitoring dashboard

> This repository is an educational software prototype. Sensor values and emergency communication are simulated and must not be used for real medical diagnosis or emergency dispatch.

## Tech Stack
- Flutter
- Dart
- Material Design

## Run
1. Install Flutter.
2. Clone/download this repository.
3. Open the project folder.
4. Run:
   ```bash
   flutter pub get
   flutter run
   ```

## Project Structure
```text
responder_guard_mobile/
├── lib/
│   └── main.dart
├── pubspec.yaml
├── analysis_options.yaml
├── .gitignore
├── LICENSE
└── README.md
```

## Future Hardware Integration
Replace the simulator with BLE sensor data from an ESP32/nRF52 wearable. A production system can add authenticated cloud APIs, real GPS, calibrated medical/environmental sensors, and verified emergency-service integrations.
